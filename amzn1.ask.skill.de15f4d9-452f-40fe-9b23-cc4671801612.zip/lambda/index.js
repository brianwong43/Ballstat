/* *
 * This sample demonstrates handling intents from an Alexa skill using the Alexa Skills Kit SDK (v2).
 * Please visit https://alexa.design/cookbook for additional examples on implementing slots, dialog management,
 * session persistence, api calls, and more.
 * */
const Alexa = require('ask-sdk-core');

const URL = "https://www.basketball-reference.com/leagues/NBA_2021_per_game.html";
 
async function getWebData(URL) {
    var https = require("https");
        return new Promise((resolve) => {
            https.get(URL, (res) => {
            if (res.statusCode !== 200) {
              console.log("statusCode = ", res.statusCode);
              return;
            }
         
            res.setEncoding("utf8");
            let body = "";
            res.on("data", (chunk) => { body += chunk; });
            res.on("end", () => {
                resolve(body);
            })
        })
    })
}


function getPlayerStats(data, boxStatCategory){
    // Process the HTML body
    var statIndex;
    if (boxStatCategory === 'points'){
        statIndex = data.indexOf('data-stat="pts_per_g"')+23;
    }
    else if (boxStatCategory === 'offensive rebounds'){
        statIndex = data.indexOf('data-stat="orb_per_g"')+23;
    }
    else if (boxStatCategory === 'defensive rebounds'){
        statIndex = data.indexOf('data-stat="drb_per_g"')+23;
    }
    else if (boxStatCategory === 'rebounds'){
        statIndex = data.indexOf('data-stat="trb_per_g"')+23;
    }
    else if (boxStatCategory === 'assists'){
        statIndex = data.indexOf('data-stat="ast_per_g"')+23;
    }
    else if (boxStatCategory === 'steals'){
        statIndex = data.indexOf('data-stat="stl_per_g"')+23;
    }
    else if (boxStatCategory === 'blocks'){
        statIndex = data.indexOf('data-stat="blk_per_g"')+23;
    }
    else if (boxStatCategory === 'turnovers'){
        statIndex = data.indexOf('data-stat="tov_per_g"')+23;
    }
    else if (boxStatCategory === 'fouls'){
        statIndex = data.indexOf('data-stat="pf_per_g"')+22;
    }
    return parseFloat(data.substring(statIndex, data.indexOf('<', statIndex)));
}

function getPlayerTotalStats(data, boxStatCategory){
    // Process the HTML body
    var statIndex;
    if (boxStatCategory === 'points'){
        statIndex = data.indexOf('data-stat="pts"')+17;
    }
    else if (boxStatCategory === 'offensive rebounds'){
        statIndex = data.indexOf('data-stat="orb"')+17;
    }
    else if (boxStatCategory === 'defensive rebounds'){
        statIndex = data.indexOf('data-stat="drb"')+17;
    }
    else if (boxStatCategory === 'rebounds'){
        statIndex = data.indexOf('data-stat="trb"')+17;
    }
    else if (boxStatCategory === 'assists'){
        statIndex = data.indexOf('data-stat="ast"')+17;
    }
    else if (boxStatCategory === 'steals'){
        statIndex = data.indexOf('data-stat="stl"')+17;
    }
    else if (boxStatCategory === 'blocks'){
        statIndex = data.indexOf('data-stat="blk"')+17;
    }
    else if (boxStatCategory === 'turnovers'){
        statIndex = data.indexOf('data-stat="tov"')+17;
    }
    else if (boxStatCategory === 'fouls'){
        statIndex = data.indexOf('data-stat="pf"')+16;
    }
    return parseFloat(data.substring(statIndex, data.indexOf('<', statIndex)));
}

const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'LaunchRequest';
    },
    handle(handlerInput) {
        const speakOutput = 'Hello, welcome to Ball Stat. I can tell you all about your favorite players stats.';
        const repromptText = 'My favorite player is Seth Curry. If you want to know his points per game, ask me how many points does Seth Curry average?';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(repromptText)
            .getResponse();
    }
};

const GetStatIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'GetStatIntent';
    },
    async handle(handlerInput) {
        var speakOutput;
        let resolutionPlayer = handlerInput.requestEnvelope.request.intent.slots.player.resolutions.resolutionsPerAuthority[0];
        let resolutionVerb = handlerInput.requestEnvelope.request.intent.slots.verb.resolutions.resolutionsPerAuthority[0];
        let resolutionBoxStatCategory = handlerInput.requestEnvelope.request.intent.slots.boxStatCategory.resolutions.resolutionsPerAuthority[0];
        if (resolutionPlayer.status.code === 'ER_SUCCESS_MATCH' && resolutionVerb.status.code === 'ER_SUCCESS_MATCH' && resolutionBoxStatCategory.status.code === 'ER_SUCCESS_MATCH'){
            var player = resolutionPlayer.values[0].value.name;
            var verb = resolutionVerb.values[0].value.name;
            var boxStatCategory = resolutionBoxStatCategory.values[0].value.name;
            
            // Web scraping
            var data = await getWebData(URL);
            var getStat;
            var index;
            var playerPageData;
            if (verb === 'average'){
                index = data.indexOf(player+'</a></td>');
                var averageData = data.substring(index, data.indexOf('</tr>', index));
                getStat = getPlayerStats(averageData, boxStatCategory);
                speakOutput = `${player} ${verb}s ${getStat} ${boxStatCategory} per game.`;
            }
            else if (verb === 'career average'){
                playerPageData = await getWebData(getPlayerPageURL(data, player));
                index = playerPageData.indexOf('Career</th>');
                var careerData = playerPageData.substring(index, playerPageData.indexOf('</tr>', index));
                getStat = getPlayerStats(careerData, boxStatCategory);
                speakOutput = `${player}s ${verb} is ${getStat} ${boxStatCategory} per game.`;
            }
            else if (verb === 'career total'){
                playerPageData = await getWebData(getPlayerPageURL(data, player));
                index = playerPageData.indexOf('Career</th>', playerPageData.indexOf('<h2>Totals'));
                var totalsData = playerPageData.substring(index, playerPageData.indexOf('</tr>', index));
                getStat = getPlayerTotalStats(totalsData, boxStatCategory);
                speakOutput = `${player} has ${getStat} total career ${boxStatCategory}.`;
            }
        } else {
            speakOutput = 'I did not catch what you said.';
            handlerInput.responseBuilder.reprompt("I'm sorry, could you say that in another way?");
        }
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt('I am sorry, I didnt catch that. Can you repeat the question?')
            .getResponse();
        
    }
};

function getPlayerPageURL(data, player){
    var lastNameLength = Math.min((player.length-player.indexOf(' ')-1),5);
    var index = data.indexOf(player+'</a></td>')-22-lastNameLength;
    var playerURL = data.substring(index, data.indexOf('"', index));
    return 'https://www.basketball-reference.com/'+playerURL;
}

const GetAdjectiveIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'GetAdjectiveIntent';
    },
    async handle(handlerInput) {
        var speakOutput;
        
        let resolutionPlayer = handlerInput.requestEnvelope.request.intent.slots.player.resolutions.resolutionsPerAuthority[0];
        let resolutionAdjective = handlerInput.requestEnvelope.request.intent.slots.adjective.resolutions.resolutionsPerAuthority[0];
        if (resolutionPlayer.status.code === 'ER_SUCCESS_MATCH' && resolutionAdjective.status.code === 'ER_SUCCESS_MATCH'){
            var player = resolutionPlayer.values[0].value.name;
            var adjective = resolutionAdjective.values[0].value.name;
            var data = await getWebData(URL);
            if (adjective === 'old'){
                adjIndex = data.indexOf('data-stat="age"', data.indexOf(player))+17;
                aSubstring = data.substring(adjIndex, data.indexOf('<', adjIndex));
                aSubstring = aSubstring+' years old';
            }
            var lastNameLength = Math.min((player.length-player.indexOf(' ')-1),5);
            var index = data.indexOf(player+'</a></td>')-22-lastNameLength;
            var dSubstring = data.substring(index, data.indexOf('"', index));
            var playerURL = 'https://www.basketball-reference.com/'+dSubstring;
            var adjIndex;
            var aSubstring;
            var playerData = await getWebData(playerURL);
            if (adjective === 'tall'){
                adjIndex = playerData.indexOf('itemprop="height"')+18;
                aSubstring = playerData.substring(adjIndex, playerData.indexOf('<', adjIndex));
                aSubstring = aSubstring.replace('-', ' foot ');
            }
            else if (adjective === 'heavy'){
                adjIndex = playerData.indexOf('itemprop="weight"')+18;
                aSubstring = playerData.substring(adjIndex, playerData.indexOf('<', adjIndex));
                aSubstring = aSubstring.replace('lb', ' pounds');
            }
            // 1. Get substring of specific player. EX: "/players/c/curryse01.html"
            // 2. Append it to "https://www.basketball-reference.com"
            // 3. Locate player adjectives in html with another getWebData()
            speakOutput = `${player} is ${aSubstring}`;
        } else {
            speakOutput = 'I did not catch what you said.';
            handlerInput.responseBuilder.reprompt("I'm sorry, could you say that in another way?");
        }
        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt('I am sorry, I didnt catch that. Can you repeat the question?')
            .getResponse();
        
    }
};



const HelpIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.HelpIntent';
    },
    handle(handlerInput) {
        const speakOutput = 'You can say hello to me! How can I help?';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && (Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.CancelIntent'
                || Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.StopIntent');
    },
    handle(handlerInput) {
        const speakOutput = 'Goodbye!';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .getResponse();
    }
};
/* *
 * FallbackIntent triggers when a customer says something that doesn’t map to any intents in your skill
 * It must also be defined in the language model (if the locale supports it)
 * This handler can be safely added but will be ingnored in locales that do not support it yet 
 * */
const FallbackIntentHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest'
            && Alexa.getIntentName(handlerInput.requestEnvelope) === 'AMAZON.FallbackIntent';
    },
    handle(handlerInput) {
        const speakOutput = 'Sorry, I don\'t know about that. Please try again.';

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};
/* *
 * SessionEndedRequest notifies that a session was ended. This handler will be triggered when a currently open 
 * session is closed for one of the following reasons: 1) The user says "exit" or "quit". 2) The user does not 
 * respond or says something that does not match an intent defined in your voice model. 3) An error occurs 
 * */
const SessionEndedRequestHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'SessionEndedRequest';
    },
    handle(handlerInput) {
        console.log(`~~~~ Session ended: ${JSON.stringify(handlerInput.requestEnvelope)}`);
        // Any cleanup logic goes here.
        return handlerInput.responseBuilder.getResponse(); // notice we send an empty response
    }
};
/* *
 * The intent reflector is used for interaction model testing and debugging.
 * It will simply repeat the intent the user said. You can create custom handlers for your intents 
 * by defining them above, then also adding them to the request handler chain below 
 * */
const IntentReflectorHandler = {
    canHandle(handlerInput) {
        return Alexa.getRequestType(handlerInput.requestEnvelope) === 'IntentRequest';
    },
    handle(handlerInput) {
        const intentName = Alexa.getIntentName(handlerInput.requestEnvelope);
        const speakOutput = `You just triggered ${intentName}`;

        return handlerInput.responseBuilder
            .speak(speakOutput)
            //.reprompt('add a reprompt if you want to keep the session open for the user to respond')
            .getResponse();
    }
};
/**
 * Generic error handling to capture any syntax or routing errors. If you receive an error
 * stating the request handler chain is not found, you have not implemented a handler for
 * the intent being invoked or included it in the skill builder below 
 * */
const ErrorHandler = {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        const speakOutput = 'Sorry, I had trouble doing what you asked. Please try again.';
        console.log(`~~~~ Error handled: ${JSON.stringify(error)}`);

        return handlerInput.responseBuilder
            .speak(speakOutput)
            .reprompt(speakOutput)
            .getResponse();
    }
};

/**
 * This handler acts as the entry point for your skill, routing all request and response
 * payloads to the handlers above. Make sure any new handlers or interceptors you've
 * defined are included below. The order matters - they're processed top to bottom 
 * */
exports.handler = Alexa.SkillBuilders.custom()
    .addRequestHandlers(
        LaunchRequestHandler,
        GetStatIntentHandler,
        GetAdjectiveIntentHandler,
        HelpIntentHandler,
        CancelAndStopIntentHandler,
        FallbackIntentHandler,
        SessionEndedRequestHandler,
        IntentReflectorHandler)
    .addErrorHandlers(
        ErrorHandler)
    .withCustomUserAgent('sample/hello-world/v1.2')
    .lambda()